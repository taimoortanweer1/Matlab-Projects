
There is a 'main' folder which contains futher two folders 
'Hough' and 'houghC'.

You need to create these two directories first to work with the compressed data. Copy image files into these two folder independently.

1. Hough folder works with the default data-set

2. HoughC folder works with the compressed data-set using one of the following methods.i.e. haar, deubecies, symlets and others. Please see the reference link for detailed wavelet filters.

'haar', 'db1', 'db2' 'db3' 'db4', 'sym2', ..., 'sym8', ...,'sym45'

https://www.mathworks.com/help/wavelet/ref/wfilters.html

You might need to adjust directories in the codes for them to work in your PC.

Lastly I have not tested the code entirely because there are image write issues in my MATLAB but I am sure that it will work but still if there's any problem you feel free to contact.

Following is the sequence of code files to be executed.
1[template,mask] = createiristemplate ('HoughC\CASIA Iris Image Database (version 1.0)\001\1\001_1_1.bmp');
2compress_all_images;
3read_all_images;
4loadimages;
5matching;
6EER_hough;

The only difference is that images are first compressed using wavelet then read_all_images is used. All the compressed images are saved in the same folder as original they are. For example the compressed version of image.jpg is saved as imageC.jpg. Plus all the compressed images are in the same directory as original ones.

If any problem please contact with no hesitation.
Thanks
Taimoor

