clear all 
close all
clc

%code without compression
[template,mask] = createiristemplate ('Hough\CASIA Iris Image Database (version 1.0)\001\1\001_1_1.bmp');
read_all_images;
loadimages;
matching;
EER_hough;

%code with compression
[template,mask] = createiristemplate ('HoughC\CASIA Iris Image Database (version 1.0)\001\1\001_1_1.bmp');
compress_all_images;
read_all_images;
loadimages;
matching;
EER_hough;


