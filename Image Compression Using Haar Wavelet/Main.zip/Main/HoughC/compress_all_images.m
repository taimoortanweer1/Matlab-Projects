% File conversion 
% Reading images from CASIA database and converting to 'jpg' format
% Author: Qingbao Guo
% Gj?vik University College, GUC, Norway


clear all;

path='HoughC\CASIA Iris Image Database (version 1.0)\00'; %please update to your directory
subpath='00'; %please update to your directory
for i=1:108
%for i=1:2
    
            if i>=10
                path='HoughC\CASIA Iris Image Database (version 1.0)\0';
                subpath='0';
            end
            
            if i>=100
                 path='HoughC\CASIA Iris Image Database (version 1.0)\';
                 subpath='';
            end
    
    for j=1:2
        
        if j==1
        for k=1:3
            
        filesrcpath1 = strcat(path,num2str(i),'\',num2str(j),'\',subpath,num2str(i),'_',num2str(j),'_',num2str(k),'.bmp');
        filedespath1 = strcat(path,num2str(i),'_',num2str(j),'_',num2str(k),'C','.jpg');
        im = imread(filesrcpath1,'bmp');
        out = imagecompression(im,4,'haar');
        %data(:,7*(i-1)+k) = reshape(im,1,280*320);
        imwrite(out,filedespath1,'jpg');       
        end
        end
        
        if j==2
        for h=1:4
        filesrcpath2 = strcat(path,num2str(i),'\',num2str(j),'\',subpath,num2str(i),'_',num2str(j),'_',num2str(h),'.bmp');
        filedespath2 = strcat(path,num2str(i),'_',num2str(j),'_',num2str(h),'C','.jpg');
        im = imread(filesrcpath2,'bmp');
        out = imagecompression(im,4,'haar');
        %data(:,7*i-4+h) = reshape(im,1,280*320);
        imwrite(out,filedespath2,'jpg');       
        end
        end
        
    end
end
%save data.mat data;