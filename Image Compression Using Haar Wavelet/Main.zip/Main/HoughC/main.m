clear all 
close all
clc

[template,mask] = createiristemplate ('CASIA Iris Image Database (version 1.0)\001\1\001_1_1.bmp');
read_all_images;
loadimages;
matching;
EER_hough;


