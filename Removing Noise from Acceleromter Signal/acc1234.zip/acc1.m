
clear all
close all



%load file
filename = {'ch1_20180225-153446.wav','ch2_20180225-153446.wav','ch2_20180225-153446.wav','ch4_20180225-153446.wav',...
            'ch4_20180225-153446.wav','ch5_20180225-153446.wav','ch6_20180225-153446.wav','ch7_20180225-153446.wav',...
            'ch8_20180225-153446.wav'};
 
 %filename{1} means load channel # 1
 %filename{2} means load channel # 2 
 % and so on
 
[sig,Fs] = audioread(filename{1}); 

wname = {'haar','sym1','sym2','sym3','sym4','sym5','sym6','sym7','sym8','db1','db2','db3','db4','db5','db6','db7','db8'};
level = {1,2,3,4,5,6,7};

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%% Block # 1 | Denoising Using a Single Interval %%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[thr,sorh,keepapp] = ddencmp('den','wv',sig);

for w = 1:1:length(wname)
for l = 1:1:length(level)
    
    sigden_1 = wdencmp('gbl',sig,wname{w},level{l},thr,sorh,keepapp);
    res = sig-sigden_1;
    sigsnr1(w,l) = snr(sigden_1);
end
end

subplot(3,1,1);
plot(sig,'r');
axis tight
title('Original Signal');

subplot(3,1,2);
plot(sigden_1,'b');
axis tight
title('Denoised Signal');

subplot(3,1,3);
plot(res,'k');
axis tight
title('Residual');


