
clear all
close all



%load file
filename = {'ch1_20180225-153446.wav','ch2_20180225-153446.wav','ch2_20180225-153446.wav','ch4_20180225-153446.wav',...
            'ch4_20180225-153446.wav','ch5_20180225-153446.wav','ch6_20180225-153446.wav','ch7_20180225-153446.wav',...
            'ch8_20180225-153446.wav'};
 
 %filename{1} means load channel # 1
 %filename{2} means load channel # 2 
 % and so on
 
[sig,Fs] = audioread(filename{1}); 

wname = {'haar','sym1','sym2','sym3','sym4','sym5','sym6','sym7','sym8','db1','db2','db3','db4','db5','db6','db7','db8'};
level = {1,2,3,4,5,6,7};


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%% Block 2 | Level-Independent Threshold - Stationary Wavelet Transform
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%adjust length of signal just to make it divisible by 2^N
sig1 = [sig;1];

 for w = 1:1:length(wname)
 for l = 1:1:length(level)
     
swc = swt(sig1,level{l},wname{w});
swcnew = swc;
ThreshSL = mean(wthrmngr('sw1ddenoLVL','heursure',swc,'sln'));

for jj = 1:level{l}
swcnew(jj,:) = wthresh(swc(jj,:),'h',ThreshSL);
end
 
noisbloc_denoised = iswt(swcnew,wname{w});
sigsnr1(w,l) = snr(noisbloc_denoised);
 end
 end
 
 subplot(2,1,1);
plot(sig1); hold on;
plot(noisbloc_denoised,'r','linewidth',2);
res = noisbloc_denoised - sig1';


