
clear all
close all



%load file
filename = {'ch1_20180225-153446.wav','ch2_20180225-153446.wav','ch2_20180225-153446.wav','ch4_20180225-153446.wav',...
            'ch4_20180225-153446.wav','ch5_20180225-153446.wav','ch6_20180225-153446.wav','ch7_20180225-153446.wav',...
            'ch8_20180225-153446.wav'};
 
 %filename{1} means load channel # 1
 %filename{2} means load channel # 2 
 % and so on
 
[sig,Fs] = audioread(filename{5}); 

wname = {'haar','sym1','sym2','sym3','sym4','sym5','sym6','sym7','sym8','db1','db2','db3','db4','db5','db6','db7','db8'};
level = {1,2,3,4,5,6,7};


%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% Block # 3 | %%%%% Advanced Automatic Interval-Dependent Denoising %%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

 wname = {'haar','sym1','sym2','sym3','sym4','sym5','sym6','sym7','sym8','db1','db2','db3','db4','db5','db6','db7','db8'};
 level = {1,2,3,4,5,6,7};   
sorh   = 's';                  % Type of thresholding.
nb_Int = 3;                    % Number of intervals for thresholding.

for w = 1:1:length(wname)
for l = 1:1:length(level)
[sigden,coefs,thrParams,int_DepThr_Cell,BestNbOfInt] = cmddenoise(sig,wname{w},level{l},sorh,nb_Int);
sigsnr1(w,l) = snr(sigden);
w,l
end
end

plot(sig,sigden)
plot(sig,'k')
hold on
plot(sigden,'r')

